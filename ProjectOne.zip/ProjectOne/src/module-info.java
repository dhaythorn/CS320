/**
 * 
 */
/**
 * 
 */
module ProjectOne {
	requires jdk.incubator.vector;
	requires junit;
}