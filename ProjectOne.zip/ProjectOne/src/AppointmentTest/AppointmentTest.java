package AppointmentTest;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThrows;

import java.util.Date;

import appointment.Appointment;

public class AppointmentTest {

    @Test
    public void testValidAppointmentCreation() {
        Date futureDate = new Date(System.currentTimeMillis() + 100000);
        Appointment appointment = new Appointment("12345", futureDate, "Doctor's appointment");
        assertEquals("12345", appointment.getAppointmentId());
        assertEquals(futureDate, appointment.getAppointmentDate());
        assertEquals("Doctor's appointment", appointment.getDescription());
    }

    @Test
    public void testInvalidAppointmentId() {
        Date futureDate = new Date(System.currentTimeMillis() + 100000);
        assertThrows(IllegalArgumentException.class, () -> new Appointment(null, futureDate, "Description"));
        assertThrows(IllegalArgumentException.class, () -> new Appointment("12345678901", futureDate, "Description"));
    }

    @Test
    public void testInvalidAppointmentDate() {
        assertThrows(IllegalArgumentException.class, () -> new Appointment("12345", new Date(), "Description"));
        assertThrows(IllegalArgumentException.class, () -> new Appointment("12345", null, "Description"));
    }

    @Test
    public void testInvalidDescription() {
        Date futureDate = new Date(System.currentTimeMillis() + 100000);
        assertThrows(IllegalArgumentException.class, () -> new Appointment("12345", futureDate, null));
        assertThrows(IllegalArgumentException.class, () -> new Appointment("12345", futureDate, "A".repeat(51)));
    }
}

