package AppointmentTest;

public @interface Test {

}
