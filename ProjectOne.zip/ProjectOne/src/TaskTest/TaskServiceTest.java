package TaskTest;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertThrows;

import task.Task;
import task.TaskService;

public class TaskServiceTest {

    @org.junit.Test
    public void testAddTask() {
        TaskService service = new TaskService();
        Task task = new Task("1", "Task 1", "Description 1");
        service.addTask(task);
        assertEquals(task, service.getTask("1"));
    }

    @org.junit.Test
    public void testAddDuplicateTask() {
        TaskService service = new TaskService();
        Task task = new Task("1", "Task 1", "Description 1");
        service.addTask(task);
        assertThrows(IllegalArgumentException.class, () -> service.addTask(task));
    }

    @org.junit.Test
    public void testDeleteTask() {
        TaskService service = new TaskService();
        Task task = new Task("1", "Task 1", "Description 1");
        service.addTask(task);
        service.deleteTask("1");
        assertNull(service.getTask("1"));
    }

    @org.junit.Test
    public void testUpdateTaskFields() {
        TaskService service = new TaskService();
        Task task = new Task("1", "Task 1", "Description 1");
        service.addTask(task);

        service.updateTaskName("1", "Updated Name");
        service.updateTaskDescription("1", "Updated Description");

        assertEquals("Updated Name", service.getTask("1").getName());
        assertEquals("Updated Description", service.getTask("1").getDescription());
    }
}
