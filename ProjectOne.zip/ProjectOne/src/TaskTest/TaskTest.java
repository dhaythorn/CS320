package TaskTest;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThrows;

import org.junit.Test;

import task.Task;

public class TaskTest {

    @org.junit.Test
    public void testTaskCreationValid() {
        Task task = new Task("123", "Test Task", "This is a test task description.");
        assertEquals("123", task.getTaskId());
        assertEquals("Test Task", task.getName());
        assertEquals("This is a test task description.", task.getDescription());
    }

    @Test
    public void testTaskCreationInvalidId() {
        assertThrows(IllegalArgumentException.class, () -> new Task(null, "Test", "Description"));
        assertThrows(IllegalArgumentException.class, () -> new Task("12345678901", "Test", "Description"));
    }

    @Test
    public void testTaskSetters() {
        Task task = new Task("123", "Test Task", "Initial description");
        task.setName("Updated Name");
        task.setDescription("Updated Description");
        assertEquals("Updated Name", task.getName());
        assertEquals("Updated Description", task.getDescription());
    }
}

